//
//  main.m
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
