//
//  ImageView.m
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import "ImageView.h"
#import "MorphEditorController.h"

@implementation ImageView

- (id)initWithFrame:(NSRect)frame 
{
    self = [super initWithFrame:frame];
    if (self)
	{
		// Basic initialisation
		NSRect r = frame;
		m_pImg = nil;
		
		m_fStartPointSelected = FALSE;
		m_nFeatureNumberSelected = m_nFeatureNumberHighlight = -1;
		m_pController = NULL;
		m_fRemovePending = FALSE;

		[[NSGraphicsContext currentContext] setImageInterpolation: NSImageInterpolationHigh];
    }
    return self;
}


-(void) setController:(MorphEditorController*)pController
{
	m_pController = pController;
}

// Draw the actual feature line. Highlighted lines are drawn differently
-(void)	drawFeatureLine:(NSPoint)startPoint end:(NSPoint)endPoint scale:(float)scale highlight:(bool)fHighlight;
{
	const float CircleRadius = 3.5;
	const float CircleWidth = 2.18;
	NSBezierPath* start;
	NSBezierPath* end;
	NSBezierPath* line;
	
	startPoint.x *= scale;
	startPoint.y *= scale;
	endPoint.x *= scale;
	endPoint.y *= scale;
	
	// Draw line
	line = [NSBezierPath bezierPath];
	[line setLineWidth: 2];

	[line  moveToPoint: startPoint];
	[line lineToPoint: endPoint];
	[line setLineCapStyle:NSSquareLineCapStyle];

	if ( fHighlight )
		[[NSColor yellowColor] set];
	else
		[[NSColor blueColor] set];
	[line stroke];

	// Start line blob
	NSRect startBlob = NSMakeRect(startPoint.x-CircleRadius, startPoint.y-CircleRadius, 2*CircleRadius, 2*CircleRadius );

	// create an oval bezier path using the rect created above
	start = [NSBezierPath bezierPathWithOvalInRect:startBlob];
	[start setLineWidth:CircleWidth];	

	// draw the start blob
	[[NSColor redColor] set];		// red shows the beginning of the line
	[start fill];
	[[NSColor blackColor] set];
	[start stroke];

	// End blob
	NSRect endBlob = NSMakeRect(endPoint.x-CircleRadius, endPoint.y-CircleRadius, 2*CircleRadius, 2*CircleRadius);

	end = [NSBezierPath bezierPathWithOvalInRect:endBlob];
	[end setLineWidth:CircleWidth];	
	
	// draw the end blob
	[[NSColor whiteColor] set];		// white shows the end of the line
	[end fill];
	[[NSColor blackColor] set];
	[end stroke];	
}

- (void)drawRect:(NSRect)dirtyRect
{
	int n;
	NSRect r = [self frame];
	float fpScale = 1.0;
	
	// First, draw the image
	if ( m_pImg )
	{
		NSRect r;

		fpScale = [self frame].size.height/double([m_pRawImg pixelsHigh]);
		r.origin = NSZeroPoint;
		r.size.height = [self frame].size.height;
		r.size.width = r.size.height * [m_pRawImg pixelsWide]/double([m_pRawImg pixelsHigh]);
		//[m_pImg drawInRect:[self frame] fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1];
		[m_pImg drawInRect:r fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1];
	}
	
	// Now, draw the features
	if ( m_pImageFeatures )
	{
		for(n=0; n< m_pImageFeatures->size(); n++)
		{
			NSPoint startPoint = NSMakePoint((*m_pImageFeatures)[n].P * vec2(1.0 , 0.0), (*m_pImageFeatures)[n].P * vec2(0.0, 1.0));
			NSPoint endPoint   = NSMakePoint((*m_pImageFeatures)[n].Q * vec2(1.0 , 0.0), (*m_pImageFeatures)[n].Q * vec2(0.0, 1.0));
			
			[self drawFeatureLine:startPoint end:endPoint scale:fpScale highlight:n==m_nFeatureNumberHighlight];
		}
	}
}

-(void) setImage:(NSImage*)pNewImg
{
    [pNewImg retain];
    [m_pImg release];

    m_pImg = pNewImg;
	m_pRawImg = [[NSBitmapImageRep alloc] initWithData:[m_pImg TIFFRepresentation]];
	
    [self setNeedsDisplay:YES];
}

-(void) setFeatures:(vector<FeatureVector>*) pFeatures
{
	int n;
	m_pImageFeatures = pFeatures;

	if ( m_pImg )
		flipFeatureVectors(*m_pImageFeatures, [m_pRawImg pixelsWide], [m_pRawImg pixelsHigh]);

//	for(n=0; n< m_pImageFeatures->size(); n++)
//		cout << "Feature[" << n << "] = " << (*m_pImageFeatures)[n].P << " -> " << (*m_pImageFeatures)[n].Q << endl;
		
	[self setNeedsDisplay:YES];
}

#pragma mark -
#pragma mark mouse event handling

- (void)mouseDown:(NSEvent *)theEvent
{
	const float fpPointWidth = 7;
	NSPoint MouseLocation = [self convertPoint:[theEvent locationInWindow] fromView:nil];
	const float fpFeatureScale = [self frame].size.height/double([m_pRawImg pixelsHigh]);
	int n;

	if ( m_pImageFeatures )
	{
		if ( m_fRemovePending )
		{
			// Check if one of our features has been clicked on
			for(n=0; n< m_pImageFeatures->size(); n++)
			{
				NSRect startPoint = NSMakeRect(fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(1.0 , 0.0))-fpPointWidth/2, fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(0.0, 1.0))-fpPointWidth/2, fpPointWidth, fpPointWidth);
				NSRect endPoint = NSMakeRect(fpFeatureScale*((*m_pImageFeatures)[n].Q * vec2(1.0 , 0.0))-fpPointWidth/2, fpFeatureScale*((*m_pImageFeatures)[n].Q * vec2(0.0, 1.0))-fpPointWidth/2, fpPointWidth, fpPointWidth);

				if ( NSPointInRect(MouseLocation, startPoint) || NSPointInRect(MouseLocation, endPoint) )
				{
					NSShowAnimationEffect(NSAnimationEffectPoof, [NSEvent mouseLocation], NSZeroSize, NULL, NULL, NULL);
					[m_pController FeatureSelectedForDelete:n];
					break;
				}
			}		
		}
		else
		{
			m_nFeatureNumberSelected = -1;

			// Check if one of our features has been clicked on
			for(n=0; n< m_pImageFeatures->size(); n++)
			{
				NSRect startPoint = NSMakeRect(fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(1.0 , 0.0))-fpPointWidth/2, fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(0.0, 1.0))-fpPointWidth/2, fpPointWidth, fpPointWidth);
				NSRect endPoint = NSMakeRect(fpFeatureScale*((*m_pImageFeatures)[n].Q * vec2(1.0 , 0.0))-fpPointWidth/2, fpFeatureScale*((*m_pImageFeatures)[n].Q * vec2(0.0, 1.0))-fpPointWidth/2, fpPointWidth, fpPointWidth);
			
				//NSLog(@"Checking Feature(%d): (%f,%f)->(%f,%f)\n", n, startPoint.origin.x, startPoint.origin.y, endPoint.origin.x, endPoint.origin.y);

				if ( NSPointInRect(MouseLocation, startPoint) )
				{
					NSLog(@"Start point of feature %d found!\n", n);

					m_fStartPointSelected = TRUE;
					m_nFeatureNumberSelected = n;
					[m_pController UserModifyingFeature:m_nFeatureNumberSelected];
				}
				if ( NSPointInRect(MouseLocation, endPoint) )
				{
					NSLog(@"End point of feature %d found!\n", n);

					m_fStartPointSelected = FALSE;
					m_nFeatureNumberSelected = n;
					[m_pController UserModifyingFeature:m_nFeatureNumberSelected];
				}
			}
		}
	}
}

- (void)mouseDragged:(NSEvent *)theEvent
{
	NSPoint MouseLocation = [self convertPoint:[theEvent locationInWindow] fromView:nil];
	const float fpFeatureScale = [self frame].size.height/double([m_pRawImg pixelsHigh]);

	if ( m_nFeatureNumberSelected >= 0 )
	{
		if ( m_fStartPointSelected )
		{
			(*m_pImageFeatures)[m_nFeatureNumberSelected].P = vec2(MouseLocation.x/fpFeatureScale, MouseLocation.y/fpFeatureScale);
			//NSLog(@"Updating start feature %d location to (%f,%f)", m_nFeatureNumberSelected, (*m_pImageFeatures)[m_nFeatureNumberSelected].P*vec2(1.0,0.0), (*m_pImageFeatures)[m_nFeatureNumberSelected].P*vec2(0.0,1.0));
		}
		else
		{
			(*m_pImageFeatures)[m_nFeatureNumberSelected].Q = vec2(MouseLocation.x/fpFeatureScale, MouseLocation.y/fpFeatureScale);
			//NSLog(@"Updating end feature %d location to (%f,%f)", m_nFeatureNumberSelected, (*m_pImageFeatures)[m_nFeatureNumberSelected].Q*vec2(1.0,0.0), (*m_pImageFeatures)[m_nFeatureNumberSelected].Q*vec2(0.0,1.0));
		}
		[self setNeedsDisplay:YES];
	}

//	NSRect startPoint = NSMakeRect(fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(1.0 , 0.0))-fpPointWidth/2, fpFeatureScale*((*m_pImageFeatures)[n].P * vec2(0.0, 1.0))-fpPointWidth/2, fpPointWidth, fpPointWidth);

	NSLog(@"mouseDragged: (%f,%f)\n", MouseLocation.x, MouseLocation.y);
}

- (void)mouseUp:(NSEvent *)theEvent
{
	m_nFeatureNumberSelected = -1;
	[m_pController UserModifyingFeature:m_nFeatureNumberSelected];
}

#pragma mark -
#pragma mark misc. functions

-(void) FeatureBeingModified:(int)nFeatureNumber
{
	m_nFeatureNumberHighlight = nFeatureNumber;
}

-(void)getNewFeaturePosition:(FeatureVector*)pFeatureVector
{
	pFeatureVector->P = vec2([m_pRawImg pixelsWide]/4.0, [m_pRawImg pixelsHigh]/8.0);
	pFeatureVector->Q = vec2([m_pRawImg pixelsWide]*3.0/4.0, [m_pRawImg pixelsHigh]/8.0);
}


-(void)removePointPending:(bool)fRemovePending
{
	m_fRemovePending = fRemovePending;
}

-(NSSize) getImageSize
{
	return NSMakeSize([m_pRawImg pixelsWide], [m_pRawImg pixelsHigh]);
}

-(bool) ImageSet
{
	return m_pImg!=nil;
}

@end
