//
//  MorphEditorController.m
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import "MorphEditorController.h"

@implementation MorphEditorController

// basic initialisation
-(void) awakeFromNib
{
	[pSrcPic setController:self];
	[pDestPic setController:self];
}

// Open a dialog and return an image
-(NSImage*) SelectImage:(NSString*) pTitle
{
	NSImage* newImage = nil;
	NSOpenPanel* openDlg = [NSOpenPanel openPanel];
	NSArray *fileTypes = [NSArray arrayWithObjects:@"bmp", @"png", @"jpg", nil];
	
	[openDlg setCanChooseFiles:YES];
	[openDlg setTitle:pTitle];
	
	if ( [openDlg runModalForDirectory:nil file:nil types:fileTypes] == NSOKButton )
	{
		NSArray* files = [openDlg filenames];
		NSString* fileName = [files objectAtIndex:0];

		if ( [[NSFileManager defaultManager] fileExistsAtPath:fileName] )
			newImage = [[NSImage alloc] initWithContentsOfFile:fileName];
	}
	
	return newImage;
}


// Handle the case when two valid pictures are now opened
-(void) initIfAllPicsLoaded
{
	if ( [pSrcPic ImageSet] && [pDestPic ImageSet] )
	{
		[pLoadFeatures setEnabled:TRUE];
		[pSaveFeatures setEnabled:Features1.size()>0];
		
		[pAddPoint setEnabled:TRUE];
		[pRemovePoint setEnabled:Features1.size()>0];
		[pMirrorPoints setEnabled:Features1.size()>0];
		
		[pSrcPic setFeatures: &Features1];		// Initialise the features (these will be blank at this point)
		[pDestPic setFeatures: &Features2];
		
		// Feature not yet available...
		[pSrcSelect setEnabled:FALSE];
		[pDestSelect setEnabled:FALSE];
	}
}


- (IBAction) SrcSelect:(id)sender
{
	NSImage* pImg = [self SelectImage: @"Select Source image"];
	
	if ( pImg )
	{
		NSBitmapImageRep* pRawSrc = [[NSBitmapImageRep alloc] initWithData:[pImg TIFFRepresentation]];

		// Check image dimensions are the same as the destination image
		if ( [pDestPic ImageSet] )
		{
			if ( [pDestPic getImageSize].height==[pRawSrc pixelsHigh] && [pDestPic getImageSize].width==[pRawSrc pixelsWide] )
			{
				[pSrcPic setImage: pImg];
			}
			else
			{
				NSRunAlertPanel(@"Error", @"Image dimensions do not match", @"Okay", @"", @"");
			}
		}
		else
		{
			[pSrcPic setImage: pImg];
		}
		
		[self initIfAllPicsLoaded];
		[pRawSrc release];
	}
}

- (IBAction) DestSelect:(id)sender
{
	NSImage* pImg = [self SelectImage: @"Select Destination image"];

	if ( pImg )
	{
		NSBitmapImageRep* pRawSrc = [[NSBitmapImageRep alloc] initWithData:[pImg TIFFRepresentation]];
		
		// Check image dimensions are the same as the source image
		if ( [pSrcPic ImageSet] )
		{
			if ( [pSrcPic getImageSize].height==[pRawSrc pixelsHigh] && [pSrcPic getImageSize].width==[pRawSrc pixelsWide] )
			{
				[pDestPic setImage: pImg];
			}
			else
			{
				NSRunAlertPanel(@"Error", @"Image dimensions do not match", @"Okay", @"", @"");
			}
		}
		else
		{
			[pDestPic setImage: pImg];
		}
		
		[self initIfAllPicsLoaded];
		[pRawSrc release];
	}

	[self initIfAllPicsLoaded];
}

// Load features from a file
- (IBAction) LoadFeaturesSelect:(id)sender
{
	NSOpenPanel* openDlg = [NSOpenPanel openPanel];
	NSArray *fileTypes = [NSArray arrayWithObjects:@"txt", nil];
	
	[openDlg setCanChooseFiles:YES];
	[openDlg setTitle:@"Load feature selection"];
	
	if ( [openDlg runModalForDirectory:nil file:nil types:fileTypes] == NSOKButton )
	{
		NSArray* files = [openDlg filenames];
		NSString* fileName = [files objectAtIndex:0];
		
		NSLog(@"selected: %@", fileName);
		
		if ( [[NSFileManager defaultManager] fileExistsAtPath:fileName] )
		{
			Features1.clear();
			Features2.clear();
			
			if ( readFeatureVectorsFromFile([fileName UTF8String], Features1, Features2) )
			{
				[pSrcPic setFeatures: &Features1];
				[pDestPic setFeatures: &Features2];
				
				[pRemovePoint setEnabled:Features1.size()>0];
				[pMirrorPoints setEnabled:Features1.size()>0];
				[pSaveFeatures setEnabled:Features1.size()>0];
			}
		}
	}
}

// Create a file of features
- (IBAction) SaveFeaturesSelect:(id)sender
{
	NSSavePanel* saveDlg = [NSSavePanel savePanel];
	
	[saveDlg setTitle:@"Save feature selection"];
	[saveDlg setRequiredFileType:@"txt"];
	
	if ( [saveDlg runModal] == NSOKButton )
	{
		NSString* fileName = [saveDlg filename];
		
		ofstream saveFile;
		saveFile.open ([fileName UTF8String]);
		
		NSLog(@"selected: %@", fileName);
		
		vector<FeatureVector>	FeaturesUnFlipped1 = Features1;
		vector<FeatureVector>	FeaturesUnFlipped2 = Features2;
		
		// Need to adjust based on the image dimensions.
		flipFeatureVectors(FeaturesUnFlipped1, [pSrcPic getImageSize].width, [pSrcPic getImageSize].height);
		flipFeatureVectors(FeaturesUnFlipped2, [pSrcPic getImageSize].width, [pSrcPic getImageSize].height);	

		saveFile <<	FeaturesUnFlipped1.size() << endl;

		for(int n=0; n< FeaturesUnFlipped1.size(); n++)
		{
			saveFile	<< FeaturesUnFlipped1[n].P*vec2(1.0,0.0) << " "
						<< FeaturesUnFlipped1[n].P*vec2(0.0,1.0) << " "
						<< FeaturesUnFlipped1[n].Q*vec2(1.0,0.0) << " "
						<< FeaturesUnFlipped1[n].Q*vec2(0.0,1.0) << " "
						<< FeaturesUnFlipped2[n].P*vec2(1.0,0.0) << " "
						<< FeaturesUnFlipped2[n].P*vec2(0.0,1.0) << " "
						<< FeaturesUnFlipped2[n].Q*vec2(1.0,0.0) << " "
						<< FeaturesUnFlipped2[n].Q*vec2(0.0,1.0) << " "
						<< endl;
		}
		saveFile.close();
	}
}

// Notify both the views that a feature is being modified
- (void) UserModifyingFeature:(int)nFeatureNumberSelected
{
	[pSrcPic FeatureBeingModified: nFeatureNumberSelected];
	[pDestPic FeatureBeingModified: nFeatureNumberSelected];
	
	[pSrcPic setNeedsDisplay:YES];
	[pDestPic setNeedsDisplay:YES];
}


// Notify both the views that a new feature is being added
- (IBAction) AddPoint:(id)sender
{	
	FeatureVector	newFeature;

	[pSrcPic getNewFeaturePosition:&newFeature];
	
	Features1.push_back(newFeature);
	Features2.push_back(newFeature);
	
	[pSrcPic setNeedsDisplay:YES];
	[pDestPic setNeedsDisplay:YES];
	
	// re-enable deletion since we've added a new point
	if ( Features1.size() )
	{
		[pRemovePoint setEnabled:TRUE];
		[pMirrorPoints setEnabled:TRUE];
		[pSaveFeatures setEnabled:TRUE];
	}
}

// Notify both the views that a new feature is being removed
- (IBAction) RemovePoint:(id)sender
{
	// Disable the add point while we wait for the remove selection to occur
	[pAddPoint setEnabled:![pRemovePoint intValue]];
	[pMirrorPoints setEnabled:![pRemovePoint intValue]];
		
	[pSrcPic removePointPending:[pRemovePoint intValue]];
	[pDestPic removePointPending:[pRemovePoint intValue]];
}

- (IBAction) MirrorPoints:(id)sender
{
	Features2.clear();
	for(int n=0; n< Features1.size(); n++)
	{
		FeatureVector New;
		New.P = vec2([pSrcPic getImageSize].width-Features1[n].P*vec2(1.0,0.0),Features1[n].P*vec2(0.0,1.0));
		New.Q = vec2([pSrcPic getImageSize].width-Features1[n].Q*vec2(1.0,0.0),Features1[n].Q*vec2(0.0,1.0));

		Features2.push_back(New);
	}
	
	[pSrcPic setNeedsDisplay:YES];
	[pDestPic setNeedsDisplay:YES];
}

// Notify both the views that a feature is being removed
-(void) FeatureSelectedForDelete:(int)nFeature
{
	// Don't allow deleting, mirroring or saving if the count is zero
	if ( 1==Features1.size() )
	{
		[pRemovePoint setIntValue:0];
		[pRemovePoint setEnabled:FALSE];
		[pMirrorPoints setEnabled:FALSE];
		[pSaveFeatures setEnabled:FALSE];
	}
	
	[pAddPoint setEnabled:![pRemovePoint intValue]];

	Features1.erase(Features1.begin() + nFeature);
	Features2.erase(Features2.begin() + nFeature);
	
	[pSrcPic removePointPending:[pRemovePoint intValue]];
	[pDestPic removePointPending:[pRemovePoint intValue]];
	[pSrcPic setNeedsDisplay:YES];
	[pDestPic setNeedsDisplay:YES];
}

@end
