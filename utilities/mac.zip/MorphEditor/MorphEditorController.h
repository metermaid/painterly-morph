//
//  MorphEditorController.h
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import <Cocoa/Cocoa.h>
#import "my_util.h"
#import "ImageView.h"

@interface MorphEditorController : NSObject
{
	IBOutlet ImageView* pSrcPic;
	IBOutlet ImageView* pDestPic;
	
	IBOutlet NSButton* pSrcSelect;
	IBOutlet NSButton* pDestSelect;
	
	IBOutlet NSButton* pLoadFeatures;
	IBOutlet NSButton* pSaveFeatures;
	
	IBOutlet NSButton* pAddPoint;
	IBOutlet NSButton* pRemovePoint;
	IBOutlet NSButton* pMirrorPoints;
	
	vector<FeatureVector>	Features1;
	vector<FeatureVector>	Features2;
}

-(void) initIfAllPicsLoaded;

-(NSImage*) SelectImage:(NSString*) pTitle;

- (IBAction) SrcSelect:(id)sender;
- (IBAction) DestSelect:(id)sender;

- (IBAction) LoadFeaturesSelect:(id)sender;
- (IBAction) SaveFeaturesSelect:(id)sender;

- (IBAction) AddPoint:(id)sender;
- (IBAction) RemovePoint:(id)sender;
- (IBAction) MirrorPoints:(id)sender;

- (void) UserModifyingFeature:(int)nFeatureNumberSelected;
-(void) FeatureSelectedForDelete:(int)nFeature;
@end
