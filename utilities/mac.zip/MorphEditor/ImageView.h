//
//  ImageView.h
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import <Cocoa/Cocoa.h>
#import "my_util.h"

@class MorphEditorController;

@interface ImageView : NSView
{
	NSImage*				m_pImg;
	NSBitmapImageRep*		m_pRawImg;
	vector<FeatureVector>*	m_pImageFeatures;
	MorphEditorController*	m_pController;
	
	bool					m_fStartPointSelected;
	int						m_nFeatureNumberSelected;
	int						m_nFeatureNumberHighlight;
	bool					m_fRemovePending;
}

-(void) setController:(MorphEditorController*)pController;
-(void) setImage:(NSImage*)pNewImg;
-(void) setFeatures:(vector<FeatureVector>*) pFeatures;
-(void)	drawFeatureLine:(NSPoint)startPoint end:(NSPoint) endPoint scale:(float)scale highlight:(bool)fHighlight;

-(void) FeatureBeingModified:(int)nFeatureNumber;

- (void)mouseDown:(NSEvent *)theEvent;
- (void)mouseDragged:(NSEvent *)theEvent;
- (void)mouseUp:(NSEvent *)theEvent;

-(void)getNewFeaturePosition:(FeatureVector*)pFeatureVector;

-(void)removePointPending:(bool)fRemovePending;

-(NSSize) getImageSize;
-(bool) ImageSet;
@end
