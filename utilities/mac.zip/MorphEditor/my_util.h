#ifndef UTIL_H_
#define UTIL_H_

// NOTE: don't include free image
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include "algebra3.h"

using namespace std;

/**
Stores a pair of feature vectors.

*/
struct FeatureVector {
	vec2 P;
	vec2 Q;
};

/**
Reads the feature vectors from a text file.
Each line of the file consists of a single pair of feature vectors.
A feature vector consists of two 2D points (x,y) defining the start and end of a
line segment defining a feature. Two feature vectors on the same line define the 
same feature on the first and second image, allowing us to calculate correspondence between images
 */

// NOTE: Added const
int readFeatureVectorsFromFile(const char* filename, vector<FeatureVector>& featuresImg1, vector<FeatureVector>& featuresImg2);

void flipFeatureVectors(vector<FeatureVector>& features,int width, int height);

#endif /* UTIL_H_ */