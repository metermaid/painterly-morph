//
//  MorphEditorAppDelegate.m
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import "MorphEditorAppDelegate.h"

@implementation MorphEditorAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
