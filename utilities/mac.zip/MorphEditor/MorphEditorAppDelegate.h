//
//  MorphEditorAppDelegate.h
//  MorphEditor
//
//  Created by Brett George on 7/6/10.
//

#import <Cocoa/Cocoa.h>

@interface MorphEditorAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
