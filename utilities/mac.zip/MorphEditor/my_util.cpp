#include "my_util.h"


// NOTE: Added const
int readFeatureVectorsFromFile(const char* filename, vector<FeatureVector>& featuresImg1, vector<FeatureVector>& featuresImg2) {
	string line;
	ifstream ifile;
	ifile.open(filename, ios::in);
	
	double asx, asy, aex, aey, bsx, bsy, bex, bey;
	int numFeatures = 0;
	
	bool firstLine = true;
	if (ifile.is_open()) {
		while (ifile.good()) {
			getline(ifile, line);
			istringstream isstream (line);
			if (firstLine) { 
				isstream >> numFeatures;
				firstLine = false;
			} else {
				isstream >> asx >> asy >> aex >> aey >> bsx >> bsy >> bex >> bey;				
				FeatureVector feature1;
				FeatureVector feature2;
				feature1.P = vec2(asx, asy);
				feature1.Q   = vec2(aex, aey);
				feature2.P = vec2(bsx, bsy);
				feature2.Q   = vec2(bex, bey);
				featuresImg1.push_back(feature1);
				featuresImg2.push_back(feature2);
			}
		}
	} else {
		return -1;
	}
	ifile.close();
	return numFeatures;
}

void flipFeatureVectors(vector<FeatureVector>& features,int width, int height) {
	for (unsigned int i = 0; i < features.size(); i++) {
		features[i].P[1] = height - features[i].P[1];
		features[i].Q[1]   = height - features[i].Q[1];
	}
}

